public class ValidationHelper
{

  public static Double tryParseDouble(String userInput) {
    try {
      return Double.parseDouble(userInput);
    } catch (Exception e) {
      return null;
    }
  }

  public static boolean isCharInRange(char ch, String range) {
    if (range == null) {
      return false;
    }
    return (range.indexOf(ch) >= 0);
  }
}
