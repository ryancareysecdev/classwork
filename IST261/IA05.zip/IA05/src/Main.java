public class Main
{
  public static void main(String[] args) {
    double operandOne = IOHelper.userInputDouble("Enter first numeric value");
    double operandTwo = IOHelper.userInputDouble("Enter second numeric value");
    char operation = IOHelper.userInputChar("Choose an operation", "+-*");

    double result;
    switch (operation) {
      case '+':
        result = MathHelper.addValues(operandOne, operandTwo);
        break;
      case '-':
        result = MathHelper.subtractValues(operandOne, operandTwo);
        break;
      case '*':
        result = MathHelper.multiplyValues(operandOne, operandTwo);
        break;
      default:
        System.out.println("Unrecognized operation!");
        return;
    }
    System.out.println("The answer is " + result);
  }
}
