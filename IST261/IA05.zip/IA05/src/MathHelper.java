public class MathHelper {
    public static double addValues(double operandOne, double operandTwo) {
        double d1 = operandOne;
        double d2 = operandTwo;
        return d1 + d2;
    }

    public static double subtractValues(double operandOne, double operandTwo) {
        double d1 = operandOne;
        double d2 = operandTwo;
        return d1 - d2;
    }

    public static double multiplyValues(double operandOne, double operandTwo) {
        double d1 = operandOne;
        double d2 = operandTwo;
        return d1 * d2;
    }

}
