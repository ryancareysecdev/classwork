import org.junit.Test;
import static org.junit.Assert.*;

public class UtilTest
{

  @Test
  public void generateRandomInt__Pass_2_10__Results_in_Range() {
    // Put your code here, then delete this comment line
  }
}
