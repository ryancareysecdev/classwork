import org.junit.Test;

import static org.junit.Assert.*;

public class ValidationHelperTest
{

  /*
   * Tests for isValidYorN
   */
  @Test
  public void isValidYorN__Pass_Y__Returns_True() {
    assertTrue(ValidationHelper.isValidYorN("Y"));
  }

  /*
   * Tests for isPositiveInt
   */

  @Test
  public void isPositiveInt__Pass_0__Returns_False() {
    assertFalse(ValidationHelper.isPositiveInt("0"));
  }
}
