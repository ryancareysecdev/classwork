public class ValidationHelper

{
  public static boolean isValidYorN(String str) {
    if ("Y".equals(str) || "N".equals(str)) {
      return true;
    }

    return false;
  }

  public static boolean isPositiveInt(String str) {
    boolean success = true;

    try {
      int parsedInt = Integer.parseInt(str);
      if (parsedInt <= 0) {
        success = false;
      }
    } catch(Exception e) {
      success = false;
    }

    return success;
  }
}
