import java.util.Scanner;

public class UIHelper
{
  private static Scanner keyboard = new Scanner(System.in);

  public String readYN(String prompt) {
    String userInput;


    while (true) {
      System.out.print(prompt);
      userInput = keyboard.nextLine();
      if (!ValidationHelper.isValidYorN(userInput)) {
        System.out.println();
        System.out.println("You must enter Y or N");
      } else {
        break;
      }
    }

    return userInput;

  }

  public int readPositiveInt(String prompt) {
    int userIntAnswer = 0;

    boolean validInt;
    do {
      validInt = true;

      System.out.print(prompt);
      String userInput = keyboard.nextLine();
      System.out.println("You answered: " + userInput);

      if (ValidationHelper.isPositiveInt(userInput)) {
        userIntAnswer = Integer.parseInt(userInput);
      } else {
        validInt = false;
      }

      if (!validInt) {
        System.out.println("You must enter a positive number with no decimals");
      }
    } while (!validInt);

    return userIntAnswer;

  }
}
