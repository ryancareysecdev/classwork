import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Util
{
  static int generateRandomEvenInt(int min, int max) {
    /*
     * To get a random integer between 2 and 10, we get a random int
     * between 1 and 5 (inclusive), then double it.
     *
     * Since Random.nextInt(5) returns a random integer between 0 and 4
     * (inclusive), we add 1 to it.  That gets us between 1 and 5.
     *
     * Doubling that result will give us the random integer between 2 and 10.
     */
    int randomInt = 2 * ThreadLocalRandom.current().nextInt(min, max/2 + 1);

    return randomInt;

  }
}
