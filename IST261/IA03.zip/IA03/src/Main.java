import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Collections;

public class Main
{

  public static void main(String[] args) {
    System.out.println("Name: Jo Student");
    System.out.println("Email: jxs5123@psu.edu");
    System.out.println("Course: IST 261");
    System.out.println("Assignment: IA03");
    System.out.println();

    String userInput = "Y";
    int count = 0;
    int correct = 0;
    int incorrect = 0;

    List<Integer> randomInts = new ArrayList<>();

    UIHelper uiHelper = new UIHelper();
    while (userInput.equals("Y")) {
      count++;
      int randomInt = Util.generateRandomEvenInt(2, 10);
      randomInts.add(randomInt);

      int userIntAnswer = uiHelper.readPositiveInt("What is half of " + randomInt + "? ");

      if (userIntAnswer == (randomInt / 2)) {
        System.out.println("Correct!");
        correct++;
      } else {
        System.out.println("Wrong!");
        incorrect++;
      }

      userInput = uiHelper.readYN("Another number (Y/N)? ");
      System.out.println();
    }

    System.out.println("Game over");
    System.out.println("You answered " + count + " questions");
    System.out.println(correct + " were right");
    System.out.println(incorrect + " were wrong");
    System.out.println("You got " + (100 * correct / count) + "% right");
    System.out.println("The highest random number you were given:  " + Collections.max(randomInts));
    System.out.println("The lowest random number you were given:  " + Collections.min(randomInts));
    System.out.println("The list of numbers you were given:");
    for (int randomInt : randomInts) {
      System.out.println(randomInt);
    }
  }
}
