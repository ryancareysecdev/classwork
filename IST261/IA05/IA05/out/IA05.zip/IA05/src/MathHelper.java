/*
 * Name: Ryan Carey
 * Email: ruc230@psu.edu
 * Course: IST 261
 * Assignment: IA04
 */
public class MathHelper {
    public static double addValues(double operandOne, double operandTwo) {
        return operandOne + operandTwo;
    }

    public static double subtractValues(double operandOne, double operandTwo) {
        return operandOne - operandTwo;
    }

    public static double multiplyValues(double operandOne, double operandTwo) {
        return operandOne * operandTwo;
    }

}
