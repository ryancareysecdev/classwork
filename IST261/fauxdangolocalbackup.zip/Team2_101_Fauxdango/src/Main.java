public class Main {

    public static void main(String[] args) {
      System.out.println("===========================");
      System.out.println("IST 261 - Team 2");

      System.out.println("Ryan Carey (ruc230@psu.edu)");
      System.out.println("Scott Charles Crowthers Jr. (scc5336@psu.edu)");
      System.out.println("John Ortiz (jjo5235@psu.edu)");
      System.out.println("Ravikar Chinnapapannagari (rfc5316@psu.edu)");
      System.out.println("===========================");
      System.out.println();

      Fauxdango f = new Fauxdango();
      f.demo();
    }
}
