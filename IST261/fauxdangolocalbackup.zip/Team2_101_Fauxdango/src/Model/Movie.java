package Model;

import java.time.Duration;
import java.time.LocalDate;

public class Movie
{
  String title;
  String description;
  LocalDate releaseDate;
  Duration runningTime;

  public Movie(String title, String description, String releaseDate, int runningTimeMinutes) {
    this.title = title;
    this.description = description;
    this.releaseDate = LocalDate.parse(releaseDate);
    // https://stackoverflow.com/a/41800301/673393
    this.runningTime = Duration.ofMinutes(runningTimeMinutes);
  }

  public Duration getRunningTime() { return runningTime; }

  public String toString() {
    int runningTimeMinutes = (int) this.getRunningTime().getSeconds() / 60;
    return String.format("%s (%s) [%s min]", this.title, this.releaseDate.getYear(), runningTimeMinutes);
  }

}
