package Model;

import java.util.ArrayList;
import java.util.List;

public class Datastore
{
  private static AdvertisementBank adBank;
  private static List<Theater> theaters;
  private static List<Movie> movies;

  public static void resetData() {
    System.out.println("Resetting 'database'");
    adBank = new AdvertisementBank();
    theaters = new ArrayList<>();
    movies = new ArrayList<>();
  }

  static {
    resetData();
    initAdvertisements();
    initTheaters();
    initMovies();
  }

  private static void initTheaters() {
    System.out.println("Initializing theaters");
    Theater theater;

    theater = new Theater("AMC Neshaminy 24", "660 Neshaminy Mall", "Bensalem", "PA", "19020", "(215) 396-8050", "https://www.amctheatres.com/movie-theatres/philadelphia/amc-neshaminy-24");
    theaters.add(theater);

    theater = new Theater("Regal UA Oxford Valley", "403 Middletown Blvd", "Langhorn", "PA", "19047", "(844) 462-7342", "https://www.regmovies.com/theatres/regal-ua-oxford-valley");
    theaters.add(theater);
  }

  private static void initAdvertisements() {
    System.out.println("Initializing advertisements");
    adBank.addAd(new Advertisement("Drink Pepsi"));
    adBank.addAd(new Advertisement("Buy Candy"));
    adBank.addAd(new Advertisement("Shop at Target"));
    adBank.addAd(new Advertisement("Watch NCIS")); }

  private static void initMovies() {
    System.out.println("Initializing movies");

    Movie movie;

    movie = new Movie("Top Gun", "Fighter pilot Maverick (Tom Cruise) flies a jet.  Goose dies.", "1986-05-16", (1 * 60 + 50));
    movies.add(movie);

    movie = new Movie("This Is Spinal Tap", "Spinal Tap, is chronicled by film director Marty DiBergi", "1984-03-02", 84);
    movies.add(movie);

    movie = new Movie("Halloween", "A masked killer named Michael Myers terrorizes a small town.", "1978-10-27", 91);
    movies.add(movie);

    movie = new Movie("Escape from New York", "In 1997, when the U.S. president crashes into Manhattan, now a giant maximum security prison, a convicted bank robber is sent in to rescue him.", "1981-07-10", 99);
    movies.add(movie);
  }

  public static List<Movie> getMovies() {
    return movies;
  }

  public static List<Theater> getTheaters() {
    return theaters;
  }

  public static AdvertisementBank getAdBank() {
    return adBank;
  }
}
