package Model;

import java.util.ArrayList;
import java.util.List;

public class AdvertisementBank
{
  private List<Advertisement> ads = new ArrayList<>();
  private int currentAdIndex = 0;

  public void addAd(Advertisement ad) {
    ads.add(ad);
  }

  public Advertisement getNextAd() {
    // TODO Write the code to get the next ad in the list.  Start back at the top after the last one
    // HINT: you'll be using the class-level "currentAdIndex" field, which currently does nothing
    return (new Advertisement("YOU STILL NEED TO CODE getNextAd()")); // TODO DELETE THIS LINE WHEN FINISHED CODING
  }

}
