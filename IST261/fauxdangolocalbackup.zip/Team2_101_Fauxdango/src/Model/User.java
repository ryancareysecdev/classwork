package Model;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class User
{
  private String firstName;
  private String lastName;
  private String emailAddress;

  public void setFirstName(String firstName) {
    // TODO write the contents of this method
  }

  public void setLastName(String lastName) {
    // TODO write the contents of this method
  }

  public void setEmailAddress(String emailAddress) {
    // TODO write the contents of this method
  }

  @Override
  public String toString() {
    // TODO:  build and return the string for the user info, then remove the "throw" line below
    throw new NotImplementedException();
  }
}
