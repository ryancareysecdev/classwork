package Model;

public class Advertisement
{
  private String text;

  public Advertisement(String text) {
    this.text = text;
  }

  public String getText() {
    return text;
  }
}
