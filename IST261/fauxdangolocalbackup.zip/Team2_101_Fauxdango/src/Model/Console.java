package Model;

import java.util.Scanner;

public class Console
{
  public static final Scanner keyboard = new Scanner(System.in);
}
