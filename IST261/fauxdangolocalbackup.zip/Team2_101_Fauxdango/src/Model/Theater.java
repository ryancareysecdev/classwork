package Model;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.List;

public class Theater
{
  private String name;
  private String streetAddress;
  private String city;
  private String state;
  private String zipCode;
  private String phoneNumber;
  private String website;

  public Theater(String name, String streetAddress, String city, String state, String zipCode, String phoneNumber, String website) {
    this.name = name;
    this.streetAddress = streetAddress;
    this.city = city;
    this.state = state;
    this.zipCode = zipCode;
    this.phoneNumber = phoneNumber;
    this.website = website;

  }

  public String toString() {
    return String.format("%s (%s, %s, %s %s) [%s]", this.name, this.streetAddress, this.city, this.state, this.zipCode, this.phoneNumber);
  }

}
