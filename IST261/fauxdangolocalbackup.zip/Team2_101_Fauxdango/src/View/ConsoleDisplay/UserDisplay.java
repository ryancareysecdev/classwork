package View.ConsoleDisplay;

import Model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class UserDisplay
{
  private final static Logger logger = LogManager.getRootLogger();

  public static User registerUser() {
    User user = new User();

    // TODO Read and store first name (use IOHelper.readNonBlankStringFromKeyboard)
    // TODO Read and store first last name (use IOHelper.readNonBlankStringFromKeyboard)
    // TODO Read and store first email address (use IOHelper.readNonBlankStringFromKeyboard)

    // TODO Log the new user, as "info" level

    return user;
  }
}
