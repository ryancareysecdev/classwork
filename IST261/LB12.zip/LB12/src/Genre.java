/*
  Name: Ryan Carey
  Project: Lab6JUnit
  Date: 9/26/2019
  Class: IST 261
*/
public class Genre {

}
