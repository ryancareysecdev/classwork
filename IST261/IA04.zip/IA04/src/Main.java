public class Main
{

  public static void main(String[] args) {
    System.out.println("Nothing going on in main");
    System.out.println("You should be running the JUnit tests");
  }
}
