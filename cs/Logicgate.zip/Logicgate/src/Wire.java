
public class Wire {

}
