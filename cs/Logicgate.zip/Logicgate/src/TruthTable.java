
public class TruthTable {

	
}
