/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Util;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author alban
 */
public class StringUtilTest {
    
    public StringUtilTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     * Test of isNullOrEmpty method, of class StringUtil.
     */
//    @Test
//    public void testIsNullOrEmpty() {
//        System.out.println("isNullOrEmpty");
//        String string = "";
//        boolean expResult = false;
//        boolean result = StringUtil.isNullOrEmpty(string);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of isNullOrWhitespace method, of class StringUtil.
     */
//    @Test
//    public void testIsNullOrWhitespace() {
//        System.out.println("isNullOrWhitespace");
//        String string = "";
//        boolean expResult = false;
//        boolean result = StringUtil.isNullOrWhitespace(string);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
