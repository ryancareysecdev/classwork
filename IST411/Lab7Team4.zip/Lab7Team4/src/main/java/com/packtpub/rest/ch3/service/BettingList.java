/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packtpub.rest.ch3.service;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Scott Jr
 */
public class BettingList {
    private static List<Bet> bets = new ArrayList<>();
    private static int currentID = 1;
    
    public static List<Bet> getList(){
        return bets;
    }
    
    public static void addBet(double amount){
        bets.add(new Bet(currentID, amount));
        currentID++;
    }
    
    public static void removeBet(int id){
        for(Bet bet : bets)
        {
            if(bet.getID() == id){
                bets.remove(bet);
            }
        }
    }
    
    public static void updateAmount(int id, double amount){
        for(Bet bet : bets){
            if(bet.getID() == id){
                bet.updateAmount(amount);
            }
        }
    }
    
    public static String printList(){
        String result = "";
        for(Bet bet : bets){
            result += "Bet " + bet.getID() + ": " + bet.getAmount() + ", ";
        }
        return result;
    }
    
    public static void main(String[] args){
        BettingList list = new BettingList();
    }
}
