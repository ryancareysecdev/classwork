/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packtpub.rest.ch3.jaxrs.service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author Scott Jr
 */
@javax.ws.rs.ApplicationPath("webresources")
public class RestAppConfig extends Application {
    @Override
    public Set<Class<?>> getClasses(){
        Set<Class<?>> resources = new java.util.HashSet<>();
        resources.add(com.packtpub.rest.ch3.service.BettingService.class);
        return resources;
    }
}

