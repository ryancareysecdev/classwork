/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packtpub.rest.ch3.service;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


/**
 *
 * @author Scott Jr
 */

@Path("bets")
public class BettingService {
    @GET
    @Path("hello")
    @Produces(MediaType.APPLICATION_JSON)
    public String helloWorld(){
        return "Hello world!!";
    }
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getBets() {
        //TODO return proper representation object
        return "<html lang=\"en\"><body><h1>Bet List- " + BettingList.printList() + "</body></h1></html>";
    }
    
    @POST
    @Path("new")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public void placeBet(@FormParam("bet") double bet) {
        BettingList.addBet(bet);
    }
    
    @PUT
    @Path("update")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public void updateBet(@FormParam("id") int id, @FormParam("bet") double bet) {
        BettingList.updateAmount(id, bet);
    }
    
    @DELETE
    @Path("delete")
    public void deleteBet(@QueryParam("id") int id) {
        BettingList.removeBet(id);
    }
}
