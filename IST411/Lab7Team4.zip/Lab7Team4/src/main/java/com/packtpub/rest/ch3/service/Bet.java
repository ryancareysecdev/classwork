/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packtpub.rest.ch3.service;

/**
 *
 * @author Scott Jr
 */
public class Bet {
    private int id;
    private double amount;   
    
    public Bet(int id, double amount){
        this.id = id;
        this.amount = amount;
    }
    
    public int getID(){
        return id;
    }
    
    public double getAmount(){
        return amount;
    }
    
    public void updateAmount(double amount){
        this.amount = amount;
    }
}
