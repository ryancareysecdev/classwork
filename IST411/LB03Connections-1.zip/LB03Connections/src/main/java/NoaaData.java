public class NoaaData {
    MetaData metadata;
    Results[] results;

    public MetaData getMetadata() {
        return metadata;
    }

    public void setMetadata(MetaData metadata) {
        this.metadata = metadata;
    }

    public Results[] getResults() {
        return results;
    }

    public void setResult(Results[] results) {
        this.results = results;
    }
}
