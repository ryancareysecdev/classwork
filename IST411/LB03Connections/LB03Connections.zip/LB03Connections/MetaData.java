/*
Project: Group Lab 3
Purpose Details: NOAA interface application
Course: IST 411
Author: Scott Crowthers, Ryan Carey
Last Date Changed: 6/9/2020
Revision: 2
*/
public class MetaData {
    ResultSet resultset;

    public ResultSet getResultset() {
        return resultset;
    }

    public void setResultset(ResultSet resultset) {
        this.resultset = resultset;
    }
}
